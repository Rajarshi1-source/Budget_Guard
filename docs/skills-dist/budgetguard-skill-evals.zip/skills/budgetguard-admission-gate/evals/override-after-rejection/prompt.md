---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

A BudgetGuard approver wants to override a blocked orders-service deploy. The gate answered `rejected` to GitHub ten minutes ago, so the Actions job already failed. How does the override get this deploy through, and what has to be true of the override record?

Answer in your reply; don't create any files.

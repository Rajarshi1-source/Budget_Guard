---
type: llm
focus: trace
weight: 1
---

The reply says the original callback cannot be reused because GitHub already rejected the job

---
type: llm
focus: trace
weight: 1
---

The reply says the override is single-use and expires (time-boxed)

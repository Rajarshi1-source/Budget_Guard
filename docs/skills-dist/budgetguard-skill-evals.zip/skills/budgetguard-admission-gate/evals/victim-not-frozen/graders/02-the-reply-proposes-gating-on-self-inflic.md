---
type: llm
focus: trace
weight: 1
---

The reply proposes gating on self-inflicted errors (self_bad / self error ratio)

---
type: llm
focus: trace
weight: 1
---

The reply says the gate's inputs use all errors and any page, so the dependency-caused burn freezes the victim

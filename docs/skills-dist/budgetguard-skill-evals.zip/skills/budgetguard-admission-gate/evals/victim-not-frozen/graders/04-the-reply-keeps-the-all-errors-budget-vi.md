---
type: llm
focus: trace
weight: 1
---

The reply keeps the all-errors budget visible on dashboards because users felt every error

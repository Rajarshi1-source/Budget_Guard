---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

During an auth-service outage, BudgetGuard froze orders-service: 95% of orders' 5xx carried error_origin=dep:auth-service, but the ACTIVE_PAGE hard stop fired anyway. Why does that happen with the Rev 2 inputs, and what change to the gate inputs fixes it?

Answer in your reply; don't create any files.

---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

In BudgetGuard's deploy.yml, `helm upgrade --install --wait` returned success but the Argo Rollout canary aborted five minutes later, and GitHub recorded a successful deployment. What should the job do instead?

Answer in your reply; don't create any files.

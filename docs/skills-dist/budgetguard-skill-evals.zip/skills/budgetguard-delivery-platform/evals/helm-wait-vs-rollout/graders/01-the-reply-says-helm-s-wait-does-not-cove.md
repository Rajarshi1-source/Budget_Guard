---
type: llm
focus: trace
weight: 1
---

The reply says Helm's wait does not cover the Rollout's steps or analysis

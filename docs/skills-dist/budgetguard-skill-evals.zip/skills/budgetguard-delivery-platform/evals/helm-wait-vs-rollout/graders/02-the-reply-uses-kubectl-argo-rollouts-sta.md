---
type: llm
focus: trace
weight: 1
---

The reply uses kubectl argo rollouts status with a timeout

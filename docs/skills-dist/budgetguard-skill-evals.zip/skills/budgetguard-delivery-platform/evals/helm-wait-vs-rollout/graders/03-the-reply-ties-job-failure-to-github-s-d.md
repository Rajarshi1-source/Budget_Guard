---
type: llm
focus: trace
weight: 1
---

The reply ties job failure to GitHub's deployment status / DORA records

---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

BudgetGuard's gate returned canary_profile [5, 25, 50, 100] for auth-service on k3s with 4 replicas. What traffic does the canary really get at the 5% step, and what has to change so the weight is real, given that auth's traffic comes from orders inside the cluster?

Answer in your reply; don't create any files.

---
type: llm
focus: trace
weight: 1
---

The reply says in-cluster calls from orders must go through the router (internal entrypoint/host), not the plain Service

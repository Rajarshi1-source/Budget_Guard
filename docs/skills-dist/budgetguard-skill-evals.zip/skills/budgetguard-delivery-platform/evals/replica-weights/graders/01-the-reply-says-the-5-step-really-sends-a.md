---
type: llm
focus: trace
weight: 1
---

The reply says the 5% step really sends about 25% (one of four replicas)

---
type: llm
focus: trace
weight: 1
---

The reply uses Argo Rollouts traffic routing through Traefik (TraefikService)

---
type: llm
focus: trace
weight: 1
---

The reply says exhaustion from full takes 50 hours

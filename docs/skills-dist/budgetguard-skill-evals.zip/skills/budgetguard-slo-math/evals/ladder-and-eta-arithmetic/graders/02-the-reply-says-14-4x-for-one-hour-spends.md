---
type: llm
focus: trace
weight: 1
---

The reply says 14.4x for one hour spends 2% of the 30-day budget

---
type: llm
focus: trace
weight: 1
---

The reply explains that the ETA depends on bad events ageing out of the rolling 30-day window (oldest buckets dropping off)

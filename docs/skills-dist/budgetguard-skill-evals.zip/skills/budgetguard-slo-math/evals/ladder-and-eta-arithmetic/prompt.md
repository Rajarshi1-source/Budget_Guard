---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

BudgetGuard interview prep: orders-service has a 99.9% availability SLO over a 30-day rolling window. Show the arithmetic for (1) the time-equivalent budget in minutes, (2) the share of the 30-day budget spent in one hour at a 14.4x burn, (3) hours from a full budget to exhaustion at 14.4x, and (4) why the unfreeze ETA is computed by replaying 5-minute buckets instead of dividing by the current burn.

Answer in your reply; don't create any files.

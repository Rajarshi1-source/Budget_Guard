---
type: llm
focus: trace
weight: 1
---

The reply classifies the absent series as NO_DATA and UNKNOWN, never HEALTHY

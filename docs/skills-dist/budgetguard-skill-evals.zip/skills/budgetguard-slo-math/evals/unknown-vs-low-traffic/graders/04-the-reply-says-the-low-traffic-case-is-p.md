---
type: llm
focus: trace
weight: 1
---

The reply says the low-traffic case is priced normally against the 30-day budget with the conservative 5-25-50-100 canary rather than treated as unknown

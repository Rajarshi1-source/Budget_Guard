---
type: llm
focus: trace
weight: 1
---

The reply says the fail-open service is admitted unverified (ADMIT_UNVERIFIED or equivalent) with a page or audit record

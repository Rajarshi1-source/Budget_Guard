---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

For BudgetGuard's gate, what SLI state and what gate verdict does orders-service (fail-open, 99.9% SLO, traffic floor 600 events/hour) get in each case: (a) the request series is absent, (b) the target is up==0, (c) 50 requests in the last hour with 80% of the 30-day budget left?

Answer in your reply; don't create any files.

---
type: llm
focus: trace
weight: 1
---

Both windows are compared against 14.4 times the allowed error ratio (0.001 for 99.9%, inlined by the generator or via bg:slo_allowed_ratio)

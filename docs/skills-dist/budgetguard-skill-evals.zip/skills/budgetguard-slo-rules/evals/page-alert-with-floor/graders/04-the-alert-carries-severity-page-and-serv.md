---
type: llm
focus: trace
weight: 1
---

The alert carries severity page and service and slo labels

---
type: llm
focus: trace
weight: 1
---

The alert includes a traffic floor using bg:requests:rate1h

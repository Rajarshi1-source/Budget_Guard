---
type: llm
focus: trace
weight: 1
---

The alert uses bg:error_ratio:rate1h and bg:error_ratio:rate5m

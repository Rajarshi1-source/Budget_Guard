---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

Write the BudgetGuard-generated Prometheus page alert for orders-service availability on the 1h/5m pair at 14.4x, including the traffic floor (min_events_per_hour 600). Use the recording-rule names the generator emits.

Answer in your reply; don't create any files.

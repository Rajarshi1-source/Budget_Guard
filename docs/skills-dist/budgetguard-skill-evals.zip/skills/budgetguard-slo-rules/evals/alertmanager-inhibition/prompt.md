---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

Write the Alertmanager route and inhibition config for BudgetGuard: page and ticket burn alerts, Slack receivers, and the BudgetGuard platform webhook that must receive both. A ticket must stay quiet while a page for the same SLO is firing.

Answer in your reply; don't create any files.

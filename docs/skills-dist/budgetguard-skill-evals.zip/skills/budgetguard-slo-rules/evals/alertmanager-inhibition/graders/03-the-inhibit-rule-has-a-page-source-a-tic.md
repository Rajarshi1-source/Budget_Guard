---
type: llm
focus: trace
weight: 1
---

The inhibit rule has a page source, a ticket target, and equal [service, slo]

---
type: llm
focus: trace
weight: 1
---

The config uses continue: true so pages also reach the BudgetGuard webhook

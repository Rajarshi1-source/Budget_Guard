---
type: llm
focus: trace
weight: 1
---

The config has a webhook receiver pointing at /v1/webhooks/alertmanager

---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

In BudgetGuard's TimescaleDB schema, should the incidents table be UNIQUE on the Alertmanager fingerprint? The Rev 2 plan says yes. Explain and give the DDL you would use.

Answer in your reply; don't create any files.

---
type: llm
focus: trace
weight: 1
---

The reply says a fingerprint-only key would corrupt MTTR

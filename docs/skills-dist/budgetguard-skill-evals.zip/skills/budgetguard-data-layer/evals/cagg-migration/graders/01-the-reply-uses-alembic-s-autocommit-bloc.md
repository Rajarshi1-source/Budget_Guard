---
type: llm
focus: trace
weight: 1
---

The reply uses Alembic's autocommit_block for the continuous aggregate

---
type: llm
focus: trace
weight: 1
---

The reply says the -oss / Apache-only TimescaleDB image lacks continuous aggregates and the TSL (community) image is needed

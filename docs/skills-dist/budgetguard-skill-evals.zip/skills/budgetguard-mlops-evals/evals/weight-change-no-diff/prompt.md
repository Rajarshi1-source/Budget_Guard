---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

I changed w_migration from 2.0 to 1.2 in BudgetGuard's policy/freeze-policy.yaml, and the policy backtest says no verdict changed even for a 900-line migration at 7% budget left. What's wrong with the backtester design, and how should a case be stored?

Answer in your reply; don't create any files.

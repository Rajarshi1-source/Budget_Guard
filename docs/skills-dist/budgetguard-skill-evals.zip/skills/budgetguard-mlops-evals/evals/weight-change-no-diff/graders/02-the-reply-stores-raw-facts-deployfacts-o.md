---
type: llm
focus: trace
weight: 1
---

The reply stores raw facts (DeployFacts or equivalent) and recomputes price per policy

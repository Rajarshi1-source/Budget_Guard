---
type: llm
focus: trace
weight: 1
---

The reply says the stored GateInput carries a precomputed price from the old weights

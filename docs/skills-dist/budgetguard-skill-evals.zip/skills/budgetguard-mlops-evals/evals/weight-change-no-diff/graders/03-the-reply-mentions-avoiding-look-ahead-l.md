---
type: llm
focus: trace
weight: 1
---

The reply mentions avoiding look-ahead / leakage when building history cases

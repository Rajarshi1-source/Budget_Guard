---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

Should BudgetGuard's Freeze Brief writer switch from gpt-5.4-mini to gpt-6-luna because it is about 7x cheaper? Describe exactly how the switch gets decided and shipped.

Answer in your reply; don't create any files.

---
type: llm
focus: trace
weight: 1
---

The reply requires repeated nightly passes (two) before promotion

---
type: llm
focus: trace
weight: 1
---

The reply ties results to the prompt version (prompt SHA)

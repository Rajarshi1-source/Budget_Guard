---
type: llm
focus: trace
weight: 1
---

The reply says the change ships as a config edit to llm.yaml

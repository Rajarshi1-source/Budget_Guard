---
type: llm
focus: trace
weight: 1
---

The reply names the grounding thresholds (99% grounding, 95% fact recall, p95 latency 4 s)

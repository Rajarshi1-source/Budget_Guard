---
type: llm
focus: trace
weight: 1
---

The reply wraps the data-fetching part in <Suspense>

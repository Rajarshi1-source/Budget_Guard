---
type: llm
focus: trace
weight: 1
---

The reply moves `await params` into the inner component inside the boundary

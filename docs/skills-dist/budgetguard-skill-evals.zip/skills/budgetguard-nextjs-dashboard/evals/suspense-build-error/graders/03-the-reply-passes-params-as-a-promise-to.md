---
type: llm
focus: trace
weight: 1
---

The reply passes params as a Promise to the inner component

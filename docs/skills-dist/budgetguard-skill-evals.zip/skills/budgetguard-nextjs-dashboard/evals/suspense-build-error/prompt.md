---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

BudgetGuard dashboard on Next.js 16 with cacheComponents: `next build` fails with 'Uncached data was accessed outside of <Suspense>' on app/decisions/[id]/page.tsx, which awaits params and fetches the decision at the top of the page. Show the fixed page structure.

Answer in your reply; don't create any files.

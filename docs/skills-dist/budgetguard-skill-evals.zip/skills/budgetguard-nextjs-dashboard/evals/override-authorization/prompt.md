---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

In BudgetGuard's Next.js dashboard, an approver signs in with GitHub and clicks Override. Who decides whether they are allowed, and how does the identity reach the platform API?

Answer in your reply; don't create any files.

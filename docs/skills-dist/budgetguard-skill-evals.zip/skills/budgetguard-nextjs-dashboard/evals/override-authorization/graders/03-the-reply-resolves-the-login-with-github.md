---
type: llm
focus: trace
weight: 1
---

The reply resolves the login with GitHub's /user endpoint

---
type: llm
focus: trace
weight: 1
---

The reply forwards the user's own GitHub token to the API

---
type: llm
focus: trace
weight: 1
---

The reply says the platform API, not the dashboard, makes the authorization decision

---
type: llm
focus: trace
weight: 1
---

The reply names the X-BG-Fault-Token header

---
type: llm
focus: trace
weight: 1
---

The reply lists ttlSeconds (auto-revert) among the body fields

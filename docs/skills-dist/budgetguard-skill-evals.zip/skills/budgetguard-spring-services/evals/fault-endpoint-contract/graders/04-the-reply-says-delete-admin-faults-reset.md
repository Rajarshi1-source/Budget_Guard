---
type: llm
focus: trace
weight: 1
---

The reply says DELETE /admin/faults resets to defaults

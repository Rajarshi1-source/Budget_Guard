---
type: llm
focus: trace
weight: 1
---

The reply names POST /admin/faults

---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

What is the contract of BudgetGuard's fault-injection admin endpoint on the services (method, body fields, auth header, reset), and why does it auto-revert?

Answer in your reply; don't create any files.

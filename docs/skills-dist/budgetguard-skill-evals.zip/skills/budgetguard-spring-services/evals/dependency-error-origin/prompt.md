---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---

In BudgetGuard's orders-service (Spring Boot 4.1, Java 21), auth-service returns 503 and orders answers its caller with 502. What error_origin value must that request carry, and where in the code is it set? Show the key Java.

Answer in your reply; don't create any files.

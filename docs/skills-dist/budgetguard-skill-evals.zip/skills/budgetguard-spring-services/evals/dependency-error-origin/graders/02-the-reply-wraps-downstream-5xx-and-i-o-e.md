---
type: llm
focus: trace
weight: 1
---

The reply wraps downstream 5xx and I/O errors in a DownstreamException (or equivalent) thrown by the client wrapper

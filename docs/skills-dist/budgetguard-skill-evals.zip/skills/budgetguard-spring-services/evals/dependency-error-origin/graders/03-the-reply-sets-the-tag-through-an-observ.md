---
type: llm
focus: trace
weight: 1
---

The reply sets the tag through an ObservationConvention reading a request attribute

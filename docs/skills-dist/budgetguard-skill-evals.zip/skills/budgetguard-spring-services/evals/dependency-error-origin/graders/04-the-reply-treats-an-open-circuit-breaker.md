---
type: llm
focus: trace
weight: 1
---

The reply treats an open circuit breaker (CallNotPermittedException) as a dependency error too

"""With-skill vs without-skill functional eval, graded by regex per grader sentence."""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from cases import CASES, TAIL

ROOT = Path(__file__).parent


def run(prompt: str, cwd: Path, model: str, timeout: int = 420) -> dict:
    cmd = ["claude", "-p", prompt, "--output-format", "json", "--model", model, "--max-turns", "12",
           "--allowedTools", "Read", "Glob", "Grep", "Skill",
           "--disallowedTools", "Bash", "Write", "Edit", "WebSearch", "WebFetch", "Agent"]
    env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}
    t0 = time.time()
    try:
        out = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
        data = json.loads(out.stdout or "{}")
        return {"text": data.get("result", ""), "cost": data.get("total_cost_usd", 0.0),
                "seconds": round(time.time() - t0, 1)}
    except Exception as exc:                                   # noqa: BLE001
        return {"text": "", "cost": 0.0, "seconds": round(time.time() - t0, 1), "error": repr(exc)}


def grade(text: str, graders: list[tuple[str, str]]) -> list[bool]:
    return [bool(re.search(rx, text)) for _, rx in graders]


def main() -> None:
    model = sys.argv[1] if len(sys.argv) > 1 else "claude-opus-5-5"
    jobs = []
    skip = set(sys.argv[2].split(",")) if len(sys.argv) > 2 else set()
    for skill, case, prompt, _, graders in CASES:
        if case in skip:
            continue
        for cond, cwd in (("with_skill", ROOT / "project2"), ("without_skill", ROOT / "baseline_project")):
            jobs.append((skill, case, cond, prompt + TAIL, cwd, graders))
    with ThreadPoolExecutor(max_workers=4) as ex:
        outs = list(ex.map(lambda j: run(j[3], j[4], model), jobs))
    rows = []
    for (skill, case, cond, _, _, graders), o in zip(jobs, outs):
        g = grade(o["text"], graders)
        rows.append({"skill": skill, "case": case, "condition": cond, "passed": sum(g), "total": len(g),
                     "checks": g, **o})
    (ROOT / "functional_results.json").write_text(json.dumps(rows, indent=2))
    by = {}
    for r in rows:
        by.setdefault(r["condition"], [0, 0])
        by[r["condition"]][0] += r["passed"]
        by[r["condition"]][1] += r["total"]
    for r in rows:
        print(f"{r['condition']:14s} {r['skill'][12:]:18s} {r['case']:28s} {r['passed']}/{r['total']}  {r['seconds']}s ${r['cost']:.2f}")
    for c, (p, t) in by.items():
        print(f"{c}: {p}/{t} = {100*p/t:.0f}%")


if __name__ == "__main__":
    main()

"""Functional eval cases: 2 per skill. Writes skill-creator case folders (prompt.md, case.yaml,
graders/NN-*.md) into each skill's evals/, and exposes regex checks for the scripted with/without run."""
from __future__ import annotations

import re
import shutil
from pathlib import Path

SKILLS = Path("/home/claude/budgetguard-skills/skills")
SETTINGS = """---
tags: [budgetguard]
max_turns: 12
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill]
---
"""
TAIL = "\n\nAnswer in your reply; don't create any files."

# (skill, case, prompt, expected_outcome, [(grader sentence, regex the reply must match)])
CASES = [
 ("budgetguard-slo-math", "unknown-vs-low-traffic",
  "For BudgetGuard's gate, what SLI state and what gate verdict does orders-service (fail-open, 99.9% SLO, traffic floor 600 events/hour) get in each case: (a) the request series is absent, (b) the target is up==0, (c) 50 requests in the last hour with 80% of the 30-day budget left?",
  "Absent series is NO_DATA and up==0 is STALE, both UNKNOWN, so a fail-open service gets an unverified admit with a page. Low traffic is not unknown: it prices against the 30-day budget, skips the short-window hard stop and uses the conservative canary.",
  [("The reply classifies the absent series as NO_DATA and UNKNOWN, never HEALTHY", r"NO_DATA"),
   ("The reply classifies up==0 as STALE", r"STALE"),
   ("The reply says the fail-open service is admitted unverified (ADMIT_UNVERIFIED or equivalent) with a page or audit record", r"(?i)admit[_ ]unverified|unverified"),
   ("The reply says the low-traffic case is priced normally against the 30-day budget with the conservative 5-25-50-100 canary rather than treated as unknown", r"5[ ,→\->]+25[ ,→\->]+50")]),
 ("budgetguard-slo-math", "ladder-and-eta-arithmetic",
  "BudgetGuard interview prep: orders-service has a 99.9% availability SLO over a 30-day rolling window. Show the arithmetic for (1) the time-equivalent budget in minutes, (2) the share of the 30-day budget spent in one hour at a 14.4x burn, (3) hours from a full budget to exhaustion at 14.4x, and (4) why the unfreeze ETA is computed by replaying 5-minute buckets instead of dividing by the current burn.",
  "43.2 minutes; 2% per hour; 50 hours; the ETA replays the oldest buckets ageing out of the rolling window, so it depends on when the bad events happened, not on the current rate.",
  [("The reply gives 43.2 minutes as the time-equivalent budget", r"43\.2"),
   ("The reply says 14.4x for one hour spends 2% of the 30-day budget", r"\b2(\.0+)?\s?%"),
   ("The reply says exhaustion from full takes 50 hours", r"\b50(\.0+)?\s?(h|hours)"),
   ("The reply explains that the ETA depends on bad events ageing out of the rolling 30-day window (oldest buckets dropping off)", r"(?i)age[sd]? out|drop(s|ping)? (out|off)|falls? out|oldest")]),
 ("budgetguard-admission-gate", "override-after-rejection",
  "A BudgetGuard approver wants to override a blocked orders-service deploy. The gate answered `rejected` to GitHub ten minutes ago, so the Actions job already failed. How does the override get this deploy through, and what has to be true of the override record?",
  "The callback is spent, so the API records a single-use, time-boxed override and re-runs the failed job; the fresh protection-rule request is admitted on an OVERRIDE lane with a conservative canary. The App needs Actions write permission.",
  [("The reply says the original callback cannot be reused because GitHub already rejected the job", r"(?i)callback"),
   ("The reply says the job is re-run (rerun-failed-jobs or equivalent) to raise a new protection-rule request", r"(?i)re-?run"),
   ("The reply says the override is single-use and expires (time-boxed)", r"(?i)single[- ]use|once|expir"),
   ("The reply says the re-run is admitted via an override lane in the gate chain", r"(?i)override lane|OVERRIDE")]),
 ("budgetguard-admission-gate", "victim-not-frozen",
  "During an auth-service outage, BudgetGuard froze orders-service: 95% of orders' 5xx carried error_origin=dep:auth-service, but the ACTIVE_PAGE hard stop fired anyway. Why does that happen with the Rev 2 inputs, and what change to the gate inputs fixes it?",
  "Rev 2 feeds the gate an all-errors remaining budget and any firing page, so D-3 is not wired in. Under charge_origin the active page counts only when the self-inflicted share of the last hour is at least the threshold, and remaining is computed from self_bad.",
  [("The reply says the gate's inputs use all errors and any page, so the dependency-caused burn freezes the victim", r"(?i)all (5xx|errors|bad)|any (firing )?page"),
   ("The reply proposes gating on self-inflicted errors (self_bad / self error ratio)", r"(?i)self_bad|self[_ -]error|self-inflicted"),
   ("The reply names a policy switch or equivalent such as attribution charge_origin", r"(?i)charge_origin|attribution"),
   ("The reply keeps the all-errors budget visible on dashboards because users felt every error", r"(?i)dashboard|users felt|both")]),
 ("budgetguard-slo-rules", "page-alert-with-floor",
  "Write the BudgetGuard-generated Prometheus page alert for orders-service availability on the 1h/5m pair at 14.4x, including the traffic floor (min_events_per_hour 600). Use the recording-rule names the generator emits.",
  "Both windows above 14.4 times the allowed ratio (the generator inlines 0.001), joined on service and slo, and an hourly request-rate floor, using bg:error_ratio:rate1h, bg:error_ratio:rate5m and bg:requests:rate1h.",
  [("The alert uses bg:error_ratio:rate1h and bg:error_ratio:rate5m", r"bg:error_ratio:rate1h[\s\S]*bg:error_ratio:rate5m|bg:error_ratio:rate5m[\s\S]*bg:error_ratio:rate1h"),
   ("Both windows are compared against 14.4 times the allowed error ratio (0.001 for 99.9%, inlined by the generator or via bg:slo_allowed_ratio)", r"14\.4\s*\*\s*(0\.001|bg:slo_allowed_ratio)|bg:slo_allowed_ratio\s*\*\s*14\.4"),
   ("The alert includes a traffic floor using bg:requests:rate1h", r"bg:requests:rate1h"),
   ("The alert carries severity page and service and slo labels", r"severity:?\s*\"?page")]),
 ("budgetguard-slo-rules", "alertmanager-inhibition",
  "Write the Alertmanager route and inhibition config for BudgetGuard: page and ticket burn alerts, Slack receivers, and the BudgetGuard platform webhook that must receive both. A ticket must stay quiet while a page for the same SLO is firing.",
  "Page route continues into the budgetguard webhook; ticket route also reaches it; inhibit ticket by page with equal service and slo.",
  [("The config uses continue: true so pages also reach the BudgetGuard webhook", r"continue:\s*true"),
   ("The config has a webhook receiver pointing at /v1/webhooks/alertmanager", r"/v1/webhooks/alertmanager"),
   ("The inhibit rule has a page source, a ticket target, and equal [service, slo]", r"equal:\s*\[\s*service,\s*slo\s*\]|equal:\s*\n\s*-\s*service\s*\n\s*-\s*slo")]),
 ("budgetguard-spring-services", "dependency-error-origin",
  "In BudgetGuard's orders-service (Spring Boot 4.1, Java 21), auth-service returns 503 and orders answers its caller with 502. What error_origin value must that request carry, and where in the code is it set? Show the key Java.",
  "dep:auth-service, set by the exception advice from a DownstreamException thrown by the downstream client wrapper, read by an ObservationConvention that adds the low-cardinality key.",
  [("The reply says the label value is dep:auth-service", r"dep:auth-service"),
   ("The reply wraps downstream 5xx and I/O errors in a DownstreamException (or equivalent) thrown by the client wrapper", r"DownstreamException"),
   ("The reply sets the tag through an ObservationConvention reading a request attribute", r"ObservationConvention"),
   ("The reply treats an open circuit breaker (CallNotPermittedException) as a dependency error too", r"CallNotPermitted")]),
 ("budgetguard-spring-services", "fault-endpoint-contract",
  "What is the contract of BudgetGuard's fault-injection admin endpoint on the services (method, body fields, auth header, reset), and why does it auto-revert?",
  "POST /admin/faults with errorRate, latencyMs, dependency, crash, ttlSeconds; X-BG-Fault-Token; DELETE resets; ttlSeconds auto-revert so a forgotten fault never burns budget.",
  [("The reply names POST /admin/faults", r"POST\s+/admin/faults"),
   ("The reply lists ttlSeconds (auto-revert) among the body fields", r"ttlSeconds"),
   ("The reply names the X-BG-Fault-Token header", r"X-BG-Fault-Token"),
   ("The reply says DELETE /admin/faults resets to defaults", r"DELETE\s+/admin/faults")]),
 ("budgetguard-data-layer", "incident-uniqueness",
  "In BudgetGuard's TimescaleDB schema, should the incidents table be UNIQUE on the Alertmanager fingerprint? The Rev 2 plan says yes. Explain and give the DDL you would use.",
  "No: a fingerprint is a hash of labels, so the same alert recurring next week has the same fingerprint; unique on (fingerprint, started_at) keeps occurrences separate and MTTR correct.",
  [("The reply says the fingerprint repeats when the same alert fires again later", r"(?i)same fingerprint|recur|fires again|hash of (the )?labels"),
   ("The reply uses UNIQUE (fingerprint, started_at)", r"UNIQUE\s*\(\s*fingerprint\s*,\s*started_at\s*\)"),
   ("The reply says a fingerprint-only key would corrupt MTTR", r"MTTR")]),
 ("budgetguard-data-layer", "cagg-migration",
  "My BudgetGuard Alembic migration that creates the sli_hourly continuous aggregate fails with 'cannot run inside a transaction block', and on another laptop it fails with a licence/feature error. Fix both.",
  "Run it inside op.get_context().autocommit_block(); use the TimescaleDB TSL image, not the -oss build, because continuous aggregates and compression are TSL features.",
  [("The reply uses Alembic's autocommit_block for the continuous aggregate", r"autocommit_block"),
   ("The reply says the -oss / Apache-only TimescaleDB image lacks continuous aggregates and the TSL (community) image is needed", r"(?i)-oss|TSL|community")]),
 ("budgetguard-mlops-evals", "weight-change-no-diff",
  "I changed w_migration from 2.0 to 1.2 in BudgetGuard's policy/freeze-policy.yaml, and the policy backtest says no verdict changed even for a 900-line migration at 7% budget left. What's wrong with the backtester design, and how should a case be stored?",
  "Cases stored a finished GateInput whose price was computed with the old weights; store the raw facts known at decision time and recompute the price per candidate policy.",
  [("The reply says the stored GateInput carries a precomputed price from the old weights", r"(?i)precomputed|already (computed|priced)|stored (GateInput|price)|old weights"),
   ("The reply stores raw facts (DeployFacts or equivalent) and recomputes price per policy", r"(?i)DeployFacts|raw facts|facts"),
   ("The reply mentions avoiding look-ahead / leakage when building history cases", r"(?i)look-?ahead|leak")]),
 ("budgetguard-mlops-evals", "model-switch-decision",
  "Should BudgetGuard's Freeze Brief writer switch from gpt-5.4-mini to gpt-6-luna because it is about 7x cheaper? Describe exactly how the switch gets decided and shipped.",
  "Cost is not the decider; the challenger runs nightly on the 120-case grounding eval and is promoted by a human PR to llm.yaml only after passing thresholds (grounding 99%, fact recall 95%, p95 4 s, zero forbidden) on two nightly runs at the current prompt SHA.",
  [("The reply names the grounding thresholds (99% grounding, 95% fact recall, p95 latency 4 s)", r"(99\s?%|0\.99)[\s\S]*(95\s?%|0\.95)"),
   ("The reply requires repeated nightly passes (two) before promotion", r"(?i)two (nightly|consecutive)|2 nightly|two runs|two nights"),
   ("The reply ties results to the prompt version (prompt SHA)", r"(?i)prompt[_ ]sha|prompt version"),
   ("The reply says the change ships as a config edit to llm.yaml", r"llm\.yaml")]),
 ("budgetguard-delivery-platform", "replica-weights",
  "BudgetGuard's gate returned canary_profile [5, 25, 50, 100] for auth-service on k3s with 4 replicas. What traffic does the canary really get at the 5% step, and what has to change so the weight is real, given that auth's traffic comes from orders inside the cluster?",
  "Without a traffic router 5% is one pod of four, 25%; use Argo Rollouts' Traefik integration and route service-to-service calls through an internal Traefik entrypoint so the weights apply.",
  [("The reply says the 5% step really sends about 25% (one of four replicas)", r"25\s?%"),
   ("The reply uses Argo Rollouts traffic routing through Traefik (TraefikService)", r"(?i)traefik"),
   ("The reply says in-cluster calls from orders must go through the router (internal entrypoint/host), not the plain Service", r"(?i)internal|in-cluster|service-to-service")]),
 ("budgetguard-delivery-platform", "helm-wait-vs-rollout",
  "In BudgetGuard's deploy.yml, `helm upgrade --install --wait` returned success but the Argo Rollout canary aborted five minutes later, and GitHub recorded a successful deployment. What should the job do instead?",
  "Helm's wait does not wait for canary analysis; the job must wait on kubectl argo rollouts status with a timeout, which exits non-zero on abort, so the deployment status reflects the canary.",
  [("The reply says Helm's wait does not cover the Rollout's steps or analysis", r"(?i)helm[\s\S]{0,120}(does not|doesn't|won't|not) (wait|know|understand)"),
   ("The reply uses kubectl argo rollouts status with a timeout", r"argo[- ]rollouts\"?\s+status"),
   ("The reply ties job failure to GitHub's deployment status / DORA records", r"(?i)deployment status|DORA|change[- ]failure")]),
 ("budgetguard-nextjs-dashboard", "override-authorization",
  "In BudgetGuard's Next.js dashboard, an approver signs in with GitHub and clicks Override. Who decides whether they are allowed, and how does the identity reach the platform API?",
  "The dashboard forwards the user's own GitHub OAuth token (X-GitHub-User-Token) with its service bearer; the API resolves the login with GET /user and checks the approvers list, so a compromised dashboard cannot name an approver.",
  [("The reply says the platform API, not the dashboard, makes the authorization decision", r"(?i)\bAPI\b[\s\S]{0,80}(decides|resolves|checks)"),
   ("The reply forwards the user's own GitHub token to the API", r"(?i)user'?s? (own )?(github )?(oauth )?(access )?token|X-GitHub-User-Token"),
   ("The reply resolves the login with GitHub's /user endpoint", r"/user\b"),
   ("The reply checks the login against an approvers list", r"(?i)approver")]),
 ("budgetguard-nextjs-dashboard", "suspense-build-error",
  "BudgetGuard dashboard on Next.js 16 with cacheComponents: `next build` fails with 'Uncached data was accessed outside of <Suspense>' on app/decisions/[id]/page.tsx, which awaits params and fetches the decision at the top of the page. Show the fixed page structure.",
  "Make the page synchronous and render a Suspense boundary around an inner async component that awaits params and fetches; keep the shell prerendered.",
  [("The reply wraps the data-fetching part in <Suspense>", r"<Suspense"),
   ("The reply moves `await params` into the inner component inside the boundary", r"await params"),
   ("The reply passes params as a Promise to the inner component", r"Promise<\{\s*id: string\s*\}>")]),
]


def slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower())[:40].strip("-")


def write_case_folders() -> None:
    for skill, case, prompt, outcome, graders in CASES:
        d = SKILLS / skill / "evals" / case
        if d.exists():
            shutil.rmtree(d)
        (d / "graders").mkdir(parents=True)
        (d / "prompt.md").write_text(SETTINGS + "\n" + prompt + TAIL + "\n")
        indented = "\n".join("  " + line for line in outcome.splitlines())
        (d / "case.yaml").write_text(f'schema_version: "1.1"\nname: {case}\nexpected_outcome: |\n{indented}\n')
        for i, (sentence, _) in enumerate(graders, 1):
            (d / "graders" / f"{i:02d}-{slug(sentence)}.md").write_text(
                "---\ntype: llm\nfocus: trace\nweight: 1\n---\n\n" + sentence + "\n")


if __name__ == "__main__":
    write_case_folders()
    print(len(CASES), "cases written")

"""Multi-skill routing eval: which BudgetGuard skill (if any) does `claude -p` load first?

All eight skills sit in <project>/.claude/skills, exactly as a user would install them, so they
compete with each other and with whatever other skills the account has. A query passes when
the first skill consulted is the expected one (or, for negatives, no BudgetGuard skill).
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).parent
PROJECT = ROOT / "project"
BG = {p.name for p in (PROJECT / ".claude" / "skills").iterdir()}


def run(query: str, model: str, timeout: int = 180) -> dict:
    cmd = ["claude", "-p", query, "--output-format", "stream-json", "--verbose",
           "--model", model, "--max-turns", "4",
           "--disallowedTools", "Bash", "Write", "Edit", "WebSearch", "WebFetch", "Agent"]
    env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}
    t0 = time.time()
    proc = subprocess.Popen(cmd, cwd=PROJECT, env=env, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    tools: list[str] = []
    skill = None
    try:
        for line in proc.stdout:                                  # type: ignore[union-attr]
            if time.time() - t0 > timeout:
                break
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue
            if ev.get("type") == "assistant":
                for c in ev["message"].get("content", []):
                    if c.get("type") != "tool_use":
                        continue
                    name, inp = c.get("name"), c.get("input", {})
                    if name == "Skill":
                        s = str(inp.get("skill", "")).split(":")[-1]
                        tools.append(f"Skill({s})")
                        skill = skill or s
                    elif name == "Read" and "SKILL.md" in str(inp.get("file_path", "")):
                        s = Path(inp["file_path"]).parent.name
                        tools.append(f"ReadSkill({s})")
                        skill = skill or s
                    else:
                        tools.append(str(name))
                if skill:
                    break
            elif ev.get("type") == "result":
                break
    finally:
        if proc.poll() is None:
            proc.kill()
        proc.wait()
    return {"skill": skill, "tools": tools[:6], "seconds": round(time.time() - t0, 1)}


def main() -> None:
    model = sys.argv[1] if len(sys.argv) > 1 else "claude-opus-5-5"
    queries = json.loads((ROOT / "queries.json").read_text())
    with ThreadPoolExecutor(max_workers=6) as ex:
        results = list(ex.map(lambda q: run(q["q"], model), queries))
    rows = []
    for q, r in zip(queries, results):
        got = r["skill"] if r["skill"] in BG else None
        rows.append({**q, "got": got, "other_skill": r["skill"] if r["skill"] and r["skill"] not in BG else None,
                     "pass": got == q["expect"], **r})
    (ROOT / "results.json").write_text(json.dumps(rows, indent=2))
    for r in rows:
        print(("PASS" if r["pass"] else "FAIL"), (r["expect"] or "-")[12:], "->", (r["got"] or "-")[12:],
              r["other_skill"] or "", "|", r["q"][:70])
    print(f"\n{sum(r['pass'] for r in rows)}/{len(rows)} passed")


if __name__ == "__main__":
    main()
